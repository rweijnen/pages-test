Before you start:
Please check if patching the original files is legal according to your country's laws.
Always make a backup copy and/or restore point before you start. 

Disclaimer:
The patches come with absolutely no warranty of any kind and are to be used only at your own risk!

Usage:
create a directory (eg C:\Patch) and extract the files to it.
copy lsm.exe, mstscax.dll and termsrv.dll from your windows\system32 folder to this directory
rename the files to *.exe.org

apply the patches (eg patch_lsm.exe lsm.exe.org lsm.exe)

Take Ownership of the original files and replace them (rename original files, stop Terminal Services etc.) and reboot afterwards.

If you didn't already install a Terminal Server patch before you can use the bat files (from the original Terminal Server patch of another author) to create required registry entries.
