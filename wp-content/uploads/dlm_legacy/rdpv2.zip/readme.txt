Author: Remko Weijnen (www.remkoweijnen.nl)
Version: 1.0
Date: 02-03-2008

License:
The contents of this file are subject to
the Mozilla Public License Version 1.1 (the "License"); you may
not use this file except in compliance with the License. You may
obtain a copy of the License at
http://www.mozilla.org/MPL/MPL-1.1.html

Software distributed under the License is distributed on an
"AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
implied. See the License for the specific language governing
rights and limitations under the License.

How to Encrypt:
Type in a password in the Password box and click Encrypt it.

How to Decrypt:
Type or paste a password hash (as saved in an rdp file but
without "password 51:b:" and press the Decrypt button.