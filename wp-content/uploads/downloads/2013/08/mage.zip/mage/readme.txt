Note: both mage.exe and mageui.exe were taken from the Microsoft Platform SDK version v6.0A and are Copyright by Microsoft.
The files are just distributed here for your convenience.