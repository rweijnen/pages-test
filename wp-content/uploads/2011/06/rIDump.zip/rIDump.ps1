﻿# Script to read the RID Pool Data for All Domain Controllers
# Written and Copyright by Remko Weijnen 2011
# Version 1.0 dd 27-06-2011
#
# The contents of this file are used with permission, subject to the Mozilla   
# Public License Version 1.1 (the "License"); you may not use this file except 
# in compliance with the License. You may obtain a copy of the License at      
#{ http://www.mozilla.org/MPL/MPL-1.1.html                                     
#                                                                              
# Software distributed under the License is distributed on an "AS IS" basis,   
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for 
# the specific language governing rights and limitations under the License.    
#                                                                              
# Alternatively, the contents of this file may be used under the terms of the  
# GNU Lesser General Public License (the  "LGPL License"), in which case the   
# provisions of the LGPL License are applicable instead of those above.        
# If you wish to allow use of your version of this file only under the terms   
# of the LGPL License and not to allow others to use your version of this file 
# under the MPL, indicate your decision by deleting  the provisions above and  
# replace  them with the notice and other provisions required by the LGPL      
# License.  If you do not delete the provisions above, a recipient may use     
# your version of this file under either the MPL or the LGPL License.          
#                                                                              
# For more information about the LGPL: http://www.gnu.org/copyleft/lesser.html 


# This functions read an Integer8 Value from Active Directory and returns an object
# with LowPart and Highpart properties
function GetInteger8([Object] $Integer8)
{
	$gp = [Reflection.Bindingflags]::GetProperty
	$objType = $Integer8.GetType()
	$objValue = $objType.InvokeMember("Value", $gp, $null, $Integer8, $null)
	$objType = $objValue.GetType()
	
	$return = New-Object -TypeName System.Object
	
	$return | Add-Member -MemberType NoteProperty -Name LowPart -Value $objType.InvokeMember("LowPart", $gp, $null, $objValue, $null)
	$return | Add-Member -MemberType NoteProperty -Name HighPart -Value $objType.InvokeMember("HighPart", $gp, $null, $objValue, $null)
	
	return $return
}

# This function returns an object with all RID Data as properties
# Note that you need to bind to the domain controller you want data from
function GetRidData([System.DirectoryServices.DirectoryEntry] $RidSet)
{
	$objParent = New-Object System.DirectoryServices.DirectoryEntry($RidSet.Parent)
	[string]$dcName = $objParent.Name
	
	$return = New-Object -TypeName System.Object
	# Domain Controller (Netbios) name
	$return | Add-Member -MemberType NoteProperty -Name DC -Value $dcName

	# rIDAllocationPool is a 64 bit value, the lowpart being the From and the highpart the To
	$AllocPool = GetInteger8 $RidSet.rIDAllocationPool
	$return | Add-Member -MemberType NoteProperty -Name rIDAllocationPoolFrom -Value $AllocPool.LowPart
	$return | Add-Member -MemberType NoteProperty -Name rIDAllocationPoolTo -Value $AllocPool.HighPart
	
	# rIDPreviousPool is a 64 bit value, the lowpart being the From and the highpart the To
	$PrevPool = GetInteger8 $RidSet.rIDPreviousAllocationPool		
	$return | Add-Member -MemberType NoteProperty -Name rIDPreviousAllocationPoolFrom -Value $PrevPool.LowPart
	$return | Add-Member -MemberType NoteProperty -Name rIDPreviousAllocationPoolTo -Value $PrevPool.HighPart
	
	# rIDPreviousPool is an array with a single value
	$return | Add-Member -MemberType NoteProperty -Name rIDNextRID -Value $RidSet.rIDNextRID[0]
	
	return $return
}

# Bind to domain
$objDomain = New-Object System.DirectoryServices.DirectoryEntry
Write-Host "Domain:" $objDomain.distinguishedName
Write-Host "Netbios name:" $objDomain.name

# Open the RID Manager Object
$strRidManager = [String]::Concat("LDAP://CN=RID Manager$,CN=System,", $objDomain.distinguishedName)
$objRidManager = New-Object System.DirectoryServices.DirectoryEntry($strRidManager)

# Check FSMO Role Owner 
$objRidMaster = New-Object System.DirectoryServices.DirectoryEntry("LDAP://" + $objRidManager.FsmoRoleOwner)
$objRidMaster = New-Object System.DirectoryServices.DirectoryEntry($objRidMaster.Parent)
Write-Host "RID Master:" $objRidMaster.name

# Read Available RID Pool
$objAvailPool = GetInteger8 $objRidManager.rIDAvailablePool
Write-Host "RidAvailablePool: from" $objAvailPool.LowPart "to" $objAvailPool.Highpart

# Create array to store RID Data
$RidDataSet = @()

# Bind to the Domain Controllers OU
$objDCOU = New-Object System.DirectoryServices.DirectoryEntry([string]::Concat("LDAP://OU=Domain Controllers,", $objDomain.distinguishedName))

# Loop through the Domain Controllers OU
foreach ($objDC in $objDCOU.Children)
{
	# Bind to the RID Set, note that's it's essential to bind to the domain controller you want data from	
	$objRIDSet = New-Object System.DirectoryServices.DirectoryEntry([string]::Concat("LDAP://", $objDC.dNSHostName, "/", $objDC.rIDSetReferences))
	
	# Add the Data to the array
	$RidDataSet += GetRidData $objRIDSet
}

# Display RID Data in a nice table
$RidDataSet | Format-Table