This driver was compiled from the sources as present in VMWare tools (linux.iso) with the following timestamps:

09-05-2010  07:17            17.987 COPYING
17-03-2011  15:34                 0 dir.txt
09-05-2010  07:17             4.388 Makefile
09-05-2010  07:17             1.582 Makefile.kernel
09-05-2010  07:17             4.224 net.h
09-05-2010  07:17             2.192 net_sg.h
09-05-2010  07:17             2.156 npa_defs.h
09-05-2010  07:17               478 README
17-03-2011  15:34    <DIR>          shared
09-05-2010  07:17             3.297 upt1_defs.h
09-05-2010  07:17             3.322 vmnet_def.h
09-05-2010  07:17            14.786 vmxnet2_def.h
09-05-2010  07:17            18.333 vmxnet3_defs.h
09-05-2010  07:17           139.475 vmxnet3_drv.c
09-05-2010  07:17             8.942 vmxnet3_int.h
09-05-2010  07:17            39.895 vmxnet3_shm.c
09-05-2010  07:17             8.495 vmxnet3_shm.h
09-05-2010  07:17             3.038 vmxnet3_shm_shared.h
09-05-2010  07:17             1.310 vmxnet3_version.h
09-05-2010  07:17             5.829 vmxnet_def.h

See http://www.remkoweijnen.nl/blog/2011/03/17/compiling-drivers-for-altiris-linux-pxe-image-part-1/
