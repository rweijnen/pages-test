Author: Danila Galimov (www.remkoweijnen.nl)
Version: 1.0
Date: 09-02-2011

History
1.0 09-09-2011 - initial release

License:

You are allowed to use these files for non-commercial proposes only.

If you require commercial usage, you must register using contact form
http://www.remkoweijnen.nl/blog/contact/
