function BinToHex {
	param(
    [Parameter(
        Position=0, 
        Mandatory=$true, 
        ValueFromPipeline=$true)
	]
	[Byte[]]$Bin)
	# assume pipeline input if we don't have an array (surely there must be a better way)
	if ($bin.Length -eq 1) {$bin = @($input)}
	$return = -join ($Bin |  foreach { "{0:X2}" -f $_ })
	Write-Output $return
}

function HexToBin {
	param(
    [Parameter(
        Position=0, 
        Mandatory=$true, 
        ValueFromPipeline=$true)
	]	
	[string]$s)
	$return = @()
	
	for ($i = 0; $i -lt $s.Length ; $i += 2)
	{
		$return += [Byte]::Parse($s.Substring($i, 2), [System.Globalization.NumberStyles]::HexNumber)
	}
	
	Write-Output $return
}

function rc4 {
	param(
    	[Byte[]]$data,
    	[Byte[]]$key
  	)

	# Make a copy of the input data
	[Byte[]]$buffer = New-Object Byte[] $data.Length
	$data.CopyTo($buffer, 0)
	
	[Byte[]]$s = New-Object Byte[] 256;
    [Byte[]]$k = New-Object Byte[] 256;

    for ($i = 0; $i -lt 256; $i++)
    {
        $s[$i] = [Byte]$i;
        $k[$i] = $key[$i % $key.Length];
    }

    $j = 0;
    for ($i = 0; $i -lt 256; $i++)
    {
        $j = ($j + $s[$i] + $k[$i]) % 256;
        $temp = $s[$i];
        $s[$i] = $s[$j];
        $s[$j] = $temp;
    }

    $i = $j = 0;
    for ($x = 0; $x -lt $buffer.Length; $x++)
    {
        $i = ($i + 1) % 256;
        $j = ($j + $s[$i]) % 256;
        $temp = $s[$i];
        $s[$i] = $s[$j];
        $s[$j] = $temp;
        [int]$t = ($s[$i] + $s[$j]) % 256;
        $buffer[$x] = $buffer[$x] -bxor $s[$t];
    }

	return $buffer
}


#Example:


$enc = [System.Text.Encoding]::ASCII
# The data we're going to encrypt
[Byte[]]$data = $enc.GetBytes("Hello World!")
# The key we're going to use
[Byte[]]$key = $enc.GetBytes("SECRET")

# Encryp the data, a byte array is returned
$EncryptedBytes = rc4 $data $key

# Convert the byte array into a hex string so we eg save it to disk
$EncryptedString = BinToHex $EncryptedBytes

# Now decrypt the data
[Byte[]]$data = HexToBin $EncryptedString
$DecryptedBytes = rc4 $data $key
$DecryptedString = $enc.GetString($DecryptedBytes)