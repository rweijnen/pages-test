import com.sun.deploy.config.Config;

import java.io.File;
import java.lang.reflect.Method;
import java.net.URLClassLoader;
import java.net.URL;

public class SetMixedCode {

    // taken from http://stackoverflow.com/questions/1010919/adding-files-to-java-classpath-at-runtime
    private static void addSoftwareLibrary(File file) throws Exception {
        Method method = URLClassLoader.class.getDeclaredMethod("addURL", new Class[]{URL.class});
        method.setAccessible(true);
        method.invoke(ClassLoader.getSystemClassLoader(), new Object[]{file.toURI().toURL()});
    }

    // get Java Home Path
    private static String getJavaHome() {
        return System.getProperty("java.home");
    }

    // I am sure there is a smarter way to do this...
    private static String getJavaLib() {
        return getJavaHome() + File.separatorChar + "lib";
    }

    // load Class at runtime (so we don't need to add it to the ClassPath)
    private static void loadClass(String fileName) throws ClassNotFoundException {
        File file = new File((getJavaLib() + File.separatorChar + fileName));
        try {
            addSoftwareLibrary(file);
        } catch (Exception e) {
            throw new ClassNotFoundException(String.format("Failed to load %s\n%s",
                    file.getAbsolutePath(), e.getStackTrace()));
        }
    }

    public static void main(String[] args) {
        int MixedMode = 0;

        System.out.println("SetMixedMode (c) 2013 Remko Weijnen");
        System.out.println("Changes Java's Mixed code setting.\n");

        try {
           loadClass("deploy.jar");
        } catch (Exception e) {
            System.err.println(e.getStackTrace());
        }

        // Print config filename
        System.out.println(String.format("Config filename: %s", Config.getUserHome() +
                File.separatorChar + Config.getPropertiesFilename()));

        // Get current value
        System.out.println(String.format("Current Value: %s\n", Config.getProperty(Config.MIXCODE_MODE_KEY)));

        // Show commandline options if argument count is 0 or argument = /? or -h
        if (args.length == 0 || args[0].equalsIgnoreCase("/?") || args[0].equalsIgnoreCase("-h")) {
            System.out.println("Argument       Matching setting in Java Control Panel");
            System.out.println("-----------------------------------------------------------------");
            System.out.println("ENABLE         Enable - show warning if needed");
            System.out.println("HIDE_RUN       Enable - hide warning and run with protections");
            System.out.println("HIDE_CANCEL    Enable - hide warning and don't run untrusted code");
            System.out.println("DISABLE        Disable verification (not recommend)\n");
            System.exit(0);
        }

        // Parse Commandline argument
        if (args[0].equalsIgnoreCase("ENABLE")) {
            MixedMode = Config.MIXCODE_ENABLE;
        } else if (args[0].equalsIgnoreCase("HIDE_RUN")) {
            MixedMode = Config.MIXCODE_HIDE_RUN;
        } else if (args[0].equalsIgnoreCase("HIDE_CANCEL")) {
            MixedMode = Config.MIXCODE_HIDE_CANCEL;
        } else if (args[0].equalsIgnoreCase("DISABLE")) {
            MixedMode = Config.MIXCODE_DISABLE;
        } else {
            System.err.println(String.format("Argument %s was not recognized", args[0]));
            System.exit(1);
        }

        if (Config.getMixcodeValue() != MixedMode) {
            System.out.println(String.format("Setting Mixed Code to: %s", args[0].toUpperCase()));
            Config.setMixcodeValue(MixedMode);
            System.out.println("Commiting changes");
            Config.store();
        } else {
            System.out.println("no changes required.");
        }
    }
}